import org.testng.annotations.Test;



public class Secondproject {

    @Test
    void setup()
    {
        System.out.println("Opening Browser");
    }


}
